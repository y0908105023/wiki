### 创建 Project
选择控制台【流连接】>【新建工程】后填写相关信息。
![](https://main.qcloudimg.com/raw/072e1af6b2d8c2c4fd396db1c7965bbc.png)

创建好的工程将在工程列表中展示。
![](https://main.qcloudimg.com/raw/47e83a96657f3e7940af45007bb11a79.png)
### 查看 Project
单击工程列表下的工程名称查看工程信息。
![](https://main.qcloudimg.com/raw/0c0f34b99c8f2ac2d13d97012b71a242.png)

###  删除 Project
需将 Project 下所有资源删除后才能删除 Project。
![](https://main.qcloudimg.com/raw/79f7a03c81e4352f1fca591c57e8282a.png)
